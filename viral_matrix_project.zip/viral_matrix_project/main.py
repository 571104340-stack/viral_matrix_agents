import time
import json
import random
from typing import List, Dict

# ANSI 颜色转义码，用于在终端中输出不同颜色的日志
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class LLM_Mock:
    """模拟大模型的 API 调用，方便本地没有 API Key 时直接运行演示"""
    @staticmethod
    def generate(prompt: str, role: str) -> str:
        time.sleep(1.5)  # 模拟网络延迟
        if "Trending" in role:
            return json.dumps([
                {"topic": "AI Agent replace coders?", "heat": 98},
                {"topic": "Latest VR Headset Review", "heat": 85}
            ])
        elif "Creator" in role:
            return json.dumps([
                {"id": 1, "platform": "Twitter", "lang": "en", "content": "Will AI Agents take our jobs? 🤖💻 Here is why you should adapt instead of panic! #AIAgent #FutureOfWork", "angle": "Tech Anxiety"},
                {"id": 2, "platform": "TikTok", "lang": "zh", "content": "[视频脚本] 震惊！AI 一天干了程序员一个月的活？三分钟带你看懂 Agent 的核心逻辑...", "angle": "Shock value"},
                {"id": 3, "platform": "Twitter", "lang": "ja", "content": "AIエージェントが仕事を奪う？むしろ適応すべき理由を解説します！ #AI #エンジニア", "angle": "Educational"}
            ])
        elif "Reviewer" in role:
            # 随机淘汰一些内容
            return json.dumps({"approved_ids": [1, 2], "rejected_ids": [3], "feedback": "Japanese tweet needs more cultural context."})
        elif "Publisher" in role:
            return "Publish success."
        return "OK"

class BaseAgent:
    def __init__(self, name: str, color: str):
        self.name = name
        self.color = color

    def log(self, message: str):
        print(f"{self.color}[{self.name} Agent]{Colors.ENDC} {message}")

class TrendSnifferAgent(BaseAgent):
    def __init__(self):
        super().__init__("🎯 Trend Sniffer", Colors.OKBLUE)

    def analyze_trends(self) -> List[Dict]:
        self.log("开始扫描全球社交媒体热点图谱 (Twitter, TikTok, YouTube)...")
        prompt = "Analyze global trends for tech products today."
        response = LLM_Mock.generate(prompt, role="Trending")
        trends = json.loads(response)
        self.log(f"发现 {len(trends)} 个高潜热点: {[t['topic'] for t in trends]}")
        return trends

class ContentMatrixAgent(BaseAgent):
    def __init__(self):
        super().__init__("✍️ Content Matrix", Colors.OKCYAN)

    def generate_content(self, trends: List[Dict]) -> List[Dict]:
        self.log("根据热点重构多语种、多角度文案矩阵...")
        prompt = f"Create 3 distinct social media posts based on: {trends[0]['topic']}"
        response = LLM_Mock.generate(prompt, role="Creator")
        contents = json.loads(response)
        for c in contents:
            self.log(f"生成草稿 -> [Platform: {c['platform']} | Lang: {c['lang']}] {c['content'][:30]}...")
        return contents

class QualityControlAgent(BaseAgent):
    def __init__(self):
        super().__init__("⚖️ Quality Control", Colors.WARNING)

    def review(self, contents: List[Dict]) -> List[Dict]:
        self.log("执行严格的 AIGC 痕迹检测与爆款潜力评估...")
        prompt = "Review the following contents and approve/reject based on engagement probability."
        response = LLM_Mock.generate(prompt, role="Reviewer")
        review_result = json.loads(response)
        
        approved_contents = [c for c in contents if c['id'] in review_result['approved_ids']]
        self.log(f"审核完毕. 通过: {len(approved_contents)} 条. 驳回理由: {review_result['feedback']}")
        return approved_contents

class ExecutionAgent(BaseAgent):
    def __init__(self):
        super().__init__("🚀 Execution & Feedback", Colors.OKGREEN)

    def publish_and_track(self, contents: List[Dict]):
        self.log("对接内容发布 API (Buffer/Hootsuite)...")
        for c in contents:
            time.sleep(0.5)
            self.log(f"✅ 成功发布到 {c['platform']} (语言: {c['lang']})")
        
        self.log("等待 1 小时后抓取初期互动数据进行策略回流...")
        time.sleep(1)
        simulated_uv = random.randint(5000, 20000)
        self.log(f"{Colors.BOLD}🎉 本轮发布预估带来自然流量 (UV): {simulated_uv}{Colors.ENDC}")

def run_viral_matrix_workflow():
    print(f"\n{Colors.HEADER}======================================================{Colors.ENDC}")
    print(f"{Colors.HEADER}🌐 启动系统：多 Agent 驱动的全球化社媒自动裂变矩阵{Colors.ENDC}")
    print(f"{Colors.HEADER}======================================================{Colors.ENDC}\n")
    
    # 初始化 Agent 群组
    sniffer = TrendSnifferAgent()
    creator = ContentMatrixAgent()
    reviewer = QualityControlAgent()
    executor = ExecutionAgent()
    
    # 步骤 1: 嗅探热点
    trends = sniffer.analyze_trends()
    time.sleep(1)
    
    # 步骤 2: 生成矩阵内容
    drafts = creator.generate_content(trends)
    time.sleep(1)
    
    # 步骤 3: 质量评审与淘汰
    final_contents = reviewer.review(drafts)
    time.sleep(1)
    
    # 步骤 4: 执行发布与闭环反馈
    if final_contents:
        executor.publish_and_track(final_contents)
    else:
        print(f"{Colors.FAIL}本轮无内容通过审核，流程终止。{Colors.ENDC}")
        
    print(f"\n{Colors.HEADER}======================================================{Colors.ENDC}")
    print(f"{Colors.HEADER}🏁 工作流执行完毕。相关 Token 消耗已上报核算系统。{Colors.ENDC}")
    print(f"{Colors.HEADER}======================================================{Colors.ENDC}\n")

if __name__ == "__main__":
    run_viral_matrix_workflow()
