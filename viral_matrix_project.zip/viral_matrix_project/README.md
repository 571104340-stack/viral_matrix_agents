# 多 Agent 驱动的全球化社媒自动裂变矩阵
(Global Viral Matrix Multi-Agent System)

## 项目简介
本项目是一个概念验证 (PoC) 级别的多 Agent 协作系统，专为出海产品或全球化品牌的社媒运营设计。通过四个专属职责的 AI Agent 深度协作，实现从热点分析、多语种内容生成、AIGC 内容审查到自动发布与数据评估的完整闭环。

## 核心工作流 (Multi-Agent Workflow)
1. **Trend Sniffer (热点嗅探 Agent)**: 实时抓取并分析全球主流平台 (X, TikTok, YouTube) 趋势。
2. **Content Matrix (内容矩阵 Agent)**: 一键生成适配各平台特性、多语种的差异化内容矩阵。
3. **Quality Control (质量控制 Agent)**: 担任毒舌评审，通过自省机制淘汰平庸的防 AIGC 检测文案。
4. **Execution (执行与反馈 Agent)**: 模拟自动化发布并收集自然流量数据(UV)作为优化依据。

## 快速启动
无需配置 API Key 即可本地查看运行效果（使用了 Mock 拦截器）：
```bash
python main.py
```
